export function nameValidator(name:undefined|string) {
  if (!name) return "Name can't be empty."
  return ''
}

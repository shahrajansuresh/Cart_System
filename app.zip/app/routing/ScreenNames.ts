export const ScreenNames= {
    Start:"Start",
    Login :"Login",
    SignUp : "SignUp",
    productList:"productList",
    cartList:"cartList",
    wishList:"wishList"

}